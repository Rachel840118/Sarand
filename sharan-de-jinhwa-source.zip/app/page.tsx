const Arrow = () => <span aria-hidden="true">↗</span>;

const navigation = [
  ["Collection", "#collection"],
  ["Maison", "#maison"],
  ["Atelier", "#atelier"],
  ["Stories", "#stories"],
];

export default function Home() {
  return (
    <main>
      <header className="site-header">
        <a className="wordmark" href="#top" aria-label="SHARAN de jinhwa home">
          SHARAN <span>de jinhwa</span>
        </a>
        <nav className="desktop-nav" aria-label="Main navigation">
          {navigation.map(([label, href]) => <a key={label} href={href}>{label}</a>)}
        </nav>
        <details className="mobile-menu">
          <summary aria-label="Open navigation"><i /><i /></summary>
          <nav>{navigation.map(([label, href]) => <a key={label} href={href}>{label}</a>)}</nav>
        </details>
      </header>

      <section className="hero" id="top">
        <div className="hero-copy">
          <p className="eyebrow">Haute Joaillerie · Seoul</p>
          <h1>Where light<br />becomes legacy.</h1>
          <p className="hero-intro">
            빛의 흐름과 손끝의 감각으로 완성하는 단 하나의 주얼리.
            시간이 지날수록 깊어지는 아름다움을 전합니다.
          </p>
          <a className="text-link" href="#collection">Discover the collection</a>
        </div>
        <figure className="hero-visual">
          <img src="/images/hero-necklace.png" alt="Flowing yellow-gold and diamond necklace" />
          <figcaption>Lumière No. 01 · 18K Gold &amp; Diamond</figcaption>
        </figure>
      </section>

      <section className="maison" id="maison">
        <p className="section-index">01 — The Maison</p>
        <div>
          <h2>Jewels that hold<br /><em>a living light.</em></h2>
          <p>
            SHARAN de jinhwa는 디자이너 문진화의 시선에서 시작됩니다.
            자연의 유려한 선, 순간의 빛, 오래 남는 기억을 귀금속과 보석에 담아
            세대를 이어갈 모던 헤리티지를 만듭니다.
          </p>
          <a className="text-link" href="#atelier">Discover our story</a>
        </div>
      </section>

      <section className="collection" id="collection">
        <div className="section-title">
          <p className="section-index">02 — Signature Collection</p>
          <h2>The Lumière<br />Collection</h2>
          <p>빛이 움직일 때마다 새로운 표정을 드러내는 조각적인 실루엣.</p>
        </div>
        <div className="product-grid">
          <article className="product-card product-necklace">
            <div className="product-image"><img src="/images/hero-necklace.png" alt="Lumière flowing gold necklace" /></div>
            <div className="product-meta"><div><p>Necklace</p><h3>Lumière No. 01</h3></div><Arrow /></div>
          </article>
          <article className="product-card">
            <div className="product-image"><img src="/images/ring.png" alt="Éclat gold and diamond ring" /></div>
            <div className="product-meta"><div><p>Ring</p><h3>Éclat No. 03</h3></div><Arrow /></div>
          </article>
          <article className="product-card">
            <div className="product-image"><img src="/images/earrings.png" alt="Ondée gold and diamond earrings" /></div>
            <div className="product-meta"><div><p>Earrings</p><h3>Ondée No. 02</h3></div><Arrow /></div>
          </article>
        </div>
      </section>

      <section className="atelier" id="atelier">
        <div className="atelier-image">
          <img src="/images/earrings.png" alt="Fine jewelry displayed on ivory sculptural plinths" />
        </div>
        <div className="atelier-copy">
          <p className="section-index">03 — Savoir-faire</p>
          <h2>Made by hand.<br />Made to remain.</h2>
          <p>
            한 줄의 스케치에서 시작해 원석을 고르고, 금속을 다듬고,
            마지막 스톤을 세팅하기까지. 모든 작품은 서울의 아틀리에에서
            천천히, 그리고 정확하게 완성됩니다.
          </p>
          <ol>
            <li><span>01</span>Hand-drawn in Seoul</li>
            <li><span>02</span>Responsibly selected stones</li>
            <li><span>03</span>Finished by master artisans</li>
          </ol>
        </div>
      </section>

      <section className="stories" id="stories">
        <p className="eyebrow">Private Atelier</p>
        <h2>Your story,<br /><em>shaped in light.</em></h2>
        <p>
          한 사람의 기억과 순간을 위한 단 하나의 작품.
          프라이빗 상담을 통해 원석 선택부터 디자인까지 함께합니다.
        </p>
        <a className="button" href="mailto:atelier@sharandejinhwa.com">Begin a commission <Arrow /></a>
      </section>

      <footer>
        <a className="wordmark" href="#top">SHARAN <span>de jinhwa</span></a>
        <p>Haute joaillerie, shaped in Seoul.</p>
        <div><a href="#collection">Collection</a><a href="#maison">Maison</a><a href="mailto:atelier@sharandejinhwa.com">Contact</a></div>
        <small>© 2026 SHARAN de jinhwa</small>
      </footer>
    </main>
  );
}
