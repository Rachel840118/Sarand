import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "SHARAN de jinhwa — Fine Jewelry Maison",
  description: "빛과 기억, 장인의 손길로 완성하는 서울의 파인 주얼리 메종.",
  other: {
    "codex-preview": "development",
  },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ko">
      <body>{children}</body>
    </html>
  );
}
